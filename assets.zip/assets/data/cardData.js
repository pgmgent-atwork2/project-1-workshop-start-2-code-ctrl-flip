const cards = [
  {
    cardId: "1",
    cardTitle: "HTML",
    cardImage: "html.png"
  },
  {
    cardId: "2",
    cardTitle: "CSS",
    cardImage: "css.png"
  },
  {
    cardId: "3",
    cardTitle: "JavaScript",
    cardImage: "javascript.png"
  },
  {
    cardId: "4",
    cardTitle: "C++",
    cardImage: "cplus.png"
  },
  {
    cardId: "5",
    cardTitle: "JSON",
    cardImage: "json.png"
  },
  {
    cardId: "6",
    cardTitle: "PHP",
    cardImage: "php.png"
  },
  {
    cardId: "7",
    cardTitle: "MySQL",
    cardImage: "sql.png"
  }
]
